/**
 * Created by jeka on 5/8/17.
 */

var preloader = document.getElementById('page-preloader');
if( !preloader.classList.contains('done')){
    preloader.classList.add('done')
}
;
